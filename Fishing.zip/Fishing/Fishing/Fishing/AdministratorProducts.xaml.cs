﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static Fishing.Variables;

namespace Fishing
{
    /// <summary>
    /// Логика взаимодействия для AdministratorProducts.xaml
    /// </summary>
    public partial class AdministratorProducts : Window
    {
        public AdministratorProducts()
        {
            InitializeComponent();
            InputFIO.Text = FIOUsers;

            ListProductBD.ItemsSource = AddDataBase.db.Tovar.ToList();
        }

        private void ButtonAddProduct(object sender, RoutedEventArgs e)
        {

        }

        private void ButtonDeleteProduct(object sender, RoutedEventArgs e)
        {

        }

        private void ButtonEditProduct(object sender, RoutedEventArgs e)
        {

        }

        private void ButtonExit(object sender, RoutedEventArgs e)
        {
            StartAutorization start = new StartAutorization();
            start.Show();

            this.Close();
        }
    }
}

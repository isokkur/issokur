﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Xml.Linq;
using static Fishing.Variables;

namespace Fishing
{
    /// <summary>
    /// Логика взаимодействия для StartAutorization.xaml
    /// </summary>
    public partial class StartAutorization : Window
    {
        public StartAutorization()
        {
            InitializeComponent();
        }

        private void ButtonAutorization(object sender, RoutedEventArgs e)
        {
           /* переменнаяСтрока названиеСтроки = XName.Тип;*/
            string inputLogin = LoginInput.Text;
            string inputPassword = PasswordInput.Text;

            /*var CurrentUser = AppDate.db.Users.FirstOrDefault(u => u.Login == log.Text && u.Parol == pass.Password);*/

            var autorization = AddDataBase.db.Users.FirstOrDefault(u => u.Login == inputLogin && u.Parol == inputPassword);

            if (autorization != null)
            {
                if (autorization.FK_Roli_sotrudnika == 1)
                {
                    FIOUsers = autorization.FIO;

                    AdministratorProducts administrator = new AdministratorProducts();
                    administrator.Show();
                    this.Close();
                }
                else
                {
                    FIOUsers = autorization.FIO;

                    ListProduct listProduct = new ListProduct();
                    listProduct.Show();

                    this.Close();

                }

            }
            else
            {
                MessageBox.Show("Повторите попытку");
            }

        }
        /*Переход на страницу каталог товаров*/

        private void ButtonGuest(object sender, RoutedEventArgs e)
        {
            FIOUsers = "Вы вошли как гость";
            ListProduct listProduct = new ListProduct();
            listProduct.Show();
            this.Close();
        }
    }
}

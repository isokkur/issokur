﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static Fishing.Variables;

namespace Fishing
{
    /// <summary>
    /// Логика взаимодействия для ListProduct.xaml
    /// </summary>
    public partial class ListProduct : Window
    {
        public ListProduct()
        {
            InitializeComponent();
            InputFIO.Text = FIOUsers;

            ListProductBD.ItemsSource = AddDataBase.db.Tovar.ToList();
           

        }

        private void ButtonExit(object sender, RoutedEventArgs e)
        {
            StartAutorization start = new StartAutorization();
            start.Show();

            this.Close();
        }

        private void ButtonSearch(object sender, RoutedEventArgs e)
        {
            string search = EnterSearch.Text;

            ListProductBD.ItemsSource = AddDataBase.db.Tovar.Where(u=>u.Name ==search).ToList();

        }
    }
}

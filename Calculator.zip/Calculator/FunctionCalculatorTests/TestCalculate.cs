using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using FunctionCalculator;

namespace FunctionCalculatorTests
{
    [TestClass]
    public class FunctionCalculatorTests
    {
        [TestMethod]
        public void TestValidInput1()
        {
            FunctionCalculator1 calculator = new FunctionCalculator1();
            double result = calculator.CalculateFunctionValue(2, 1);
            Assert.AreEqual(1.0, result);
        }

        [TestMethod]
        public void TestValidInput2()
        {
            FunctionCalculator1 calculator = new FunctionCalculator1();
            double result = calculator.CalculateFunctionValue(3, 2);
            Assert.AreEqual(1.0, result);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestDivisionByZero()
        {
            FunctionCalculator1 calculator = new FunctionCalculator1();
            calculator.CalculateFunctionValue(5, 5);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestOutOfRange()
        {
            FunctionCalculator1 calculator = new FunctionCalculator1    ();
            calculator.CalculateFunctionValue(10, 10);
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp5
{
    /// <summary>
    /// Логика взаимодействия для admin.xaml
    /// </summary>
    public partial class admin : Window
    {
        private List<string> records;

        public admin()
        {
            InitializeComponent();
            records = new List<string>();
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            string newRecord = RecordTextBox.Text.Trim();
            if (!string.IsNullOrEmpty(newRecord))
            {
                records.Add(newRecord);
                UpdateRecordsListBox();
                RecordTextBox.Clear();
            }
            else
            {
                MessageBox.Show("Please enter a record.");
            }
        }

        private void UpdateRecordsListBox()
        {
            RecordsListBox.Items.Clear();
            foreach (string record in records)
            {
                RecordsListBox.Items.Add(record);
            }
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            mw.Show();
            this.Close();
        }
    }
}

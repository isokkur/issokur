﻿using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;

namespace WpfApp5
{
    public partial class MainWindow : Window
    {
        private List<User> users = new List<User>();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void RegisterButton_Click(object sender, RoutedEventArgs e)
        {
            string username = RegisterUsername.Text;
            string password = RegisterPassword.Password;
            string role = (RegisterRole.SelectedItem as ComboBoxItem)?.Content.ToString(); // Получаем выбранную роль

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password) || string.IsNullOrEmpty(role))
            {
                MessageBox.Show("Пожалуйста, заполните все поля.");
                return;
            }

            if (users.Exists(user => user.Username == username))
            {
                MessageBox.Show("Пользователь с таким именем уже существует.");
                return;
            }

            users.Add(new User { Username = username, Password = password, Role = role });
            MessageBox.Show("Регистрация прошла успешно!");
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            string username = LoginUsername.Text;
            string password = LoginPassword.Password;

            User foundUser = users.Find(u => u.Username == username && u.Password == password);

            if (foundUser != null)
            {
                MessageBox.Show($"Вы успешно вошли в систему как {foundUser.Role}!");

                // Проверка роли
                if (foundUser.Role == "Администратор")
                {
                    // Логика для администраторов
                    MessageBox.Show("Добро пожаловать, администратор!");
                    admin f = new admin();
                    f.Show();
                    this.Close();
                }
                else
                {
                    // Логика для обычных пользователей
                    MessageBox.Show("Добро пожаловать, пользователь!");
                    UserDefolt ff = new UserDefolt();
                    ff.Show();
                    this.Close();

                }
            }
            else
            {
                MessageBox.Show("Неправильное имя пользователя или пароль.");
            }
        }
    }
}

            


﻿using System.Windows;

namespace WpfApp5
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string loginTxt = Login.Text.ToString();
            string passwordTxt = password.Text.ToString();
            if (loginTxt == "Admnin" && passwordTxt == "123")
            {
                MessageBox.Show($"Вы вошли как {loginTxt}");
                
                admin f = new admin();
                f.Show();
                this.Close();

            }
            if (loginTxt == "User" && passwordTxt == "123")
            {
                MessageBox.Show($"Вы вошли как {loginTxt}");

                User ff = new User();
                ff.Show();
                this.Close();

            }
            else
            {
                MessageBox.Show($"Вы ввели неправельный логин или пароль!");
            }
        }
    }
}

